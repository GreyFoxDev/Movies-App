import HomeScreen from "../components/HomeScreen";

const HomePage = () => {
  return <HomeScreen />;
};

export default HomePage;
