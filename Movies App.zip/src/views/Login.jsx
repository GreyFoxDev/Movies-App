import LoginScreen from "../components/LoginScreen";
const LoginPage = () => {
  return <LoginScreen />;
};

export default LoginPage;
