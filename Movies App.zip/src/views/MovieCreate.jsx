import React from "react";
import MovieCreateScreen from "../components/Movies/MoviesCreate";

const MovieCreate = () => {
  return <MovieCreateScreen />;
};

export default MovieCreate;
