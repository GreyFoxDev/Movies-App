export const moviesData = [
  {
    title: "movie 1",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 2",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 3",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 4",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 5",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 6",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 7",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 8",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 9",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 10",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 11",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 12",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 13",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 14",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 15",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 16",
    poster: "/movie2.png",
    publishYear: 2021,
  },
  {
    title: "movie 17",
    poster: "/movie1.png",
    publishYear: 2021,
  },
  {
    title: "movie 18",
    poster: "/movie1.png",
    publishYear: 2021,
  },

  {
    title: "movie 19",
    poster: "/movie3.png",
    publishYear: 2021,
  },
  {
    title: "movie 20",
    poster: "/movie2.png",
    publishYear: 2021,
  },
];
